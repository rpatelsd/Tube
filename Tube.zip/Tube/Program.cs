﻿using System;
using TubeLibrary;

namespace TubeClient
{
    class Program
    {
        public static void Main(string[] args)
        {
            var reader = new StationReader();
            var tube = new Tube(reader);

            var stations = tube.GetStationsNHopsAway("East Ham", 5);

            foreach (var station in stations)
            {
                Console.WriteLine(station);
            }

            Console.ReadKey();
        }
    }
}
