﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace TubeLibrary
{
    public class TubeDFS
    {
        Dictionary<string, HashSet<string>> stations = null;
        public Stack<string> stack = new Stack<string>();

        public TubeDFS(IReader stationReader)
        {
            stations = stationReader.GetStations();
            stack.Push("East Ham");
        }
        Dictionary<int, HashSet<string>> depthVisitor = new Dictionary<int,HashSet<string>>();
            HashSet<string> visited = new HashSet<string>();
            

        public void GetStationsNHopsAwayRecursive(string startStation, int hops)
        {
            //if (visited.Contains(startStation))
            //    return;

            if(depthVisitor.ContainsKey(hops))
            {
                depthVisitor[hops].Add(startStation);
            }
            else
            {
                depthVisitor[hops] = new HashSet<string> { startStation };
            }

            visited.Add(startStation);

            if (hops == 0)
            {
                Console.WriteLine(startStation);
                return;
            }
            
            foreach (var st in stations[startStation].Except(visited))
            {
                GetStationsNHopsAwayRecursive(st, hops - 1);
            }


            
        }

        public List<string> GetStationsNHopsAway(string startStation, int hops)
        {
            var visited = new HashSet<string>();
            var returnList = new List<string>();

            if (!stations.ContainsKey(startStation))
                return returnList;

            var stack = new Stack<string>();
            var countStack = new Stack<int>();
            stack.Push(startStation);
            countStack.Push(0);

            while (stack.Count > 0)
            {
                var vertex = stack.Pop();
                var depth = countStack.Pop();

                if (depth == 5)
                    Console.WriteLine(vertex);

                if (depth > 5)
                    continue;


                if (visited.Contains(vertex))
                    continue;

                visited.Add(vertex);

                foreach (var neighbor in stations[vertex].Except(visited))
                {
                    stack.Push(neighbor);
                    countStack.Push(depth + 1);
                }
            }

            return returnList;
        }

        private List<string> CurateList(List<Tuple<int, string>> depthTracker, int hops)
        {
            var s = depthTracker
                    .Where(x => x.Item1 == hops)
                    .Select(x => x.Item2).ToList()
                    .Except(
                            depthTracker
                            .Where(z => z.Item1 != hops)
                            .Select(z => z.Item2).ToList()
                            );

            return s.OrderBy(x => x).ToList();
        }
    }
}
